//const { url } = require("inspector");

/* Global Variables */
let bsaeURL = 'http://api.openweathermap.org/data/2.5/weather'
let apiKey = '0c3facf6b0b8fe296bbb2c08dc467631';
// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();

document.getElementById('generate').addEventListener('click',performAction);
function performAction(){
    const zipCode = document.getElementById("zip").value;
    const feelings = document.getElementById("feelings").value;
    getAll(bsaeURL,zipCode,apiKey)
       .then(function(data){
        console.log(data);
        postData('/add',{date:newDate,temp: data.main.temp,content: feelings})
        .then(()=>{
            updateUI();

        })
        
        
       })


};

//Get API data
const getAll = async (baseURL, zipCode, apiKey)=>{
    const res = await fetch(`${baseURL}?zip=${zipCode}&appid=${apiKey}&units=imperial`)
    try{
        const data = await res.json();
        return data;

    }catch(error){
        console.log('error',error);
    }
}


//async get

const updateUI = async()=>{
    const request = await fetch('/all');
    try{
        const allData = await request.json();
        console.log(allData);
        document.getElementById('temp').innerHTML= Math.round(allData.temp)+ ' degree';
        document.getElementById('content').innerHTML= allData.content;
        document.getElementById('date').innerHTML= allData.date;
        
    }catch(error){
        console.log('error',error);
    }
};

//async post
const postData = async(url='',data={})=>{
    const response = await fetch(url,{
        method: 'POST',
        credentials: 'same-origin',
        headers:{
            'Content-Type':'application/json',
        },
        body: JSON.stringify(data),
    });
    try {
        const newDate = await response.text();
        return newDate;
    } catch(error) {
        console.log('error',error);

    }
};

